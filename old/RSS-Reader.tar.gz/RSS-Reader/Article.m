//
//  Article.m
//  Project1Solution
//
//  Created by Michael Griepentrog on 2/3/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Article.h"


@implementation Article

@synthesize title, date, url, description;

@end
